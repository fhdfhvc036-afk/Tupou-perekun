# Перекуп: телефоны — сборка APK

В архиве два способа получить APK. Игра уже лежит внутри, ничего дописывать не нужно.

```
android/   готовый Android-проект (WebView, без сторонних библиотек)
web/       сама игра одним файлом index.html (для способа Б)
```

Требуется Android 8.0+ (minSdk 26). Игра работает полностью офлайн.

## Способ А. Android Studio (проще всего)

1. Установи Android Studio (она сама поставит JDK и Android SDK).
2. File → Open → выбери папку `android/`.
3. Дождись синхронизации Gradle (нужен интернет, один раз).
4. Build → Build Bundle(s) / APK(s) → **Build APK(s)**.
5. Файл появится здесь: `android/app/build/outputs/apk/debug/app-debug.apk`.
6. Перекинь на телефон, разреши установку из неизвестных источников и открой. Или подключи телефон по USB и нажми Run ▶.

### Из командной строки

Нужны JDK 17 и Android SDK (переменная `ANDROID_HOME` или файл `android/local.properties` со строкой `sdk.dir=/путь/к/Android/Sdk`).

```
cd android
gradle wrapper --gradle-version 8.7     # один раз, создаст ./gradlew
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Способ Б. Capacitor (если уже есть Node.js)

```
npm init -y
npm i @capacitor/core @capacitor/cli @capacitor/android
npx cap init Перекуп ru.perekup.phones --web-dir=web
npx cap add android
npx cap sync
npx cap open android      # откроется Android Studio, дальше Build APK(s)
```

## Подпись для публикации

Debug-APK подходит для установки у себя. Для Google Play или раздачи другим:
Build → Generate Signed Bundle / APK → создай ключ (keystore) и сохрани его. Потеряешь ключ — не сможешь обновлять приложение.

## Что можно поменять

- Название: `android/app/src/main/res/values/strings.xml`.
- Идентификатор приложения (`ru.perekup.phones`): в `app/build.gradle` (`namespace`, `applicationId`) и имя пакета в `MainActivity.java`.
- Иконка: `res/drawable/ic_launcher_foreground.xml` и `ic_launcher_background.xml`.
- Игра: `android/app/src/main/assets/index.html`.

## Заметки

- Прогресс игры хранится в localStorage WebView: он пропадёт, если очистить данные приложения или удалить его.
- Кнопка «Назад» сначала закрывает открытую шторку игры, а потом выходит из приложения.
- Тёмная тема включается по настройке телефона (Android 10+).
- Шрифт Roboto Flex в офлайн-версию не включён, вместо него системный шрифт.
- В архиве нет файла `gradle-wrapper.jar`: Android Studio скачает нужный Gradle сам.
